package com.example.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day5ClassExcerciseApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day5ClassExcerciseApplication.class, args);
	}

}
